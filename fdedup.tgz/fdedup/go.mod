module ffdup

go 1.23.4

require (
	github.com/mattn/go-sqlite3 v1.14.44
	github.com/zeebo/blake3 v0.2.4
)

require github.com/klauspost/cpuid/v2 v2.0.12 // indirect
