package main

import (
	"log"

	"fddup/internal/db"
	"fddup/internal/model"
	"fddup/internal/output"
	"fddup/internal/scan"
)

func main() {
	cfg := model.Config{
		Roots: []string{"."},
	}

	store, err := db.Open("file.db")
	if err != nil {
		log.Fatal(err)
	}
	defer store.Close()

	scanner := scan.New(store, cfg)

	hashMap, err := scanner.Run()
	if err != nil {
		log.Fatal(err)
	}

	output.Emit(cfg, hashMap)
}
