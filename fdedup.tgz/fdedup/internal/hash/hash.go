package hash

import (
	"encoding/hex"
	"io"
	"os"
	"sync"

	"github.com/zeebo/blake3"
)

const BufferSize = 1024 * 1024

var bufPool = sync.Pool{
	New: func() any {
		b := make([]byte, BufferSize)
		return &b
	},
}

func File(path string) (string, error) {
	f, err := os.Open(path)
	if err != nil {
		return "", err
	}
	defer f.Close()

	h := blake3.New()

	bufPtr := bufPool.Get().(*[]byte)
	defer bufPool.Put(bufPtr)

	_, err = io.CopyBuffer(h, f, *bufPtr)
	if err != nil {
		return "", err
	}

	return hex.EncodeToString(h.Sum(nil)), nil
}

func Quick(path string) (string, error) {
	f, err := os.Open(path)
	if err != nil {
		return "", err
	}
	defer f.Close()

	bufPtr := bufPool.Get().(*[]byte)
	defer bufPool.Put(bufPtr)

	buf := *bufPtr

	n, err := io.ReadFull(f, buf)
	if err != nil && err != io.EOF && err != io.ErrUnexpectedEOF {
		return "", err
	}

	sum := blake3.Sum256(buf[:n])

	return hex.EncodeToString(sum[:]), nil
}
