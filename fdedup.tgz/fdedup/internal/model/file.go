package model

type FileEntry struct {
	Path string
	Size int64
	Hash string
}
