package config

type Config struct {
	Roots   []string
	Exclude []string
	Delete  bool
	DryRun  bool
	JSON    bool
	Quiet   bool
}
