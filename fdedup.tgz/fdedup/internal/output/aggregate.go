package output

func Aggregate(
	entries []model.FileEntry,
) map[string][]string {
	aggregate := make(map[string][]string)

	for _, entry := range entries {
		aggregate[entry.Hash] = append(aggregate[entry.Hash], entry.Path)
	}

	return aggregate
}
