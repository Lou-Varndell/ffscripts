package scan

import (
	"fmt"
	"io/fs"
	"log"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"sync"

	"fddup/internal/db"
	"fddup/internal/hash"
	"fddup/internal/model"
)

type Scanner struct {
	Store  *db.Store
	Config model.Config
}

func New(store *db.Store, cfg model.Config) *Scanner {
	return &Scanner{
		Store:  store,
		Config: cfg,
	}
}

// Run is now orchestration glue only.
func (s *Scanner) Run() ([]model.FileEntry, error) {
	paths, err := s.WalkFiles()
	if err != nil {
		return nil, err
	}

	sizeMap, err := s.GroupBySize(paths)
	if err != nil {
		return nil, err
	}

	candidates, err := s.QuickHashCandidates(sizeMap)
	if err != nil {
		return nil, err
	}

	results, err := s.FullHash(candidates)
	if err != nil {
		return nil, err
	}

	if err := s.Persist(results); err != nil {
		return nil, err
	}

	return AggregateDuplicates(results), nil
}

// WalkFiles returns all candidate file paths.
func (s *Scanner) WalkFiles() ([]string, error) {
	var paths []string

	for _, root := range s.Config.Roots {
		err := filepath.WalkDir(
			root,
			func(path string, d fs.DirEntry, err error) error {
				if err != nil {
					log.Printf("walk error: %s: %v", path, err)
					return nil
				}

				if d.IsDir() {
					if s.skipDir(root, d.Name(), path) {
						return filepath.SkipDir
					}
					return nil
				}

				// Skip symlinks.
				if d.Type()&fs.ModeSymlink != 0 {
					return nil
				}

				info, err := d.Info()
				if err != nil {
					log.Printf("stat error: %s: %v", path, err)
					return nil
				}

				// Ignore empty files.
				if info.Size() == 0 {
					return nil
				}

				paths = append(paths, path)

				return nil
			},
		)

		if err != nil {
			return nil, err
		}
	}

	return paths, nil
}

func (s *Scanner) GroupBySize(
	paths []string,
) (map[int64][]string, error) {

	sizeMap := make(map[int64][]string)

	for _, path := range paths {
		info, err := os.Stat(path)
		if err != nil {
			log.Printf("stat error: %s: %v", path, err)
			continue
		}

		sizeMap[info.Size()] = append(
			sizeMap[info.Size()],
			path,
		)
	}

	return sizeMap, nil
}

// QuickHashCandidates performs fast partial hashing
// and returns only collision candidates.
func (s *Scanner) QuickHashCandidates(
	sizeMap map[int64][]string,
) (map[string][]model.FileEntry, error) {

	quickMap := make(map[string][]model.FileEntry)

	for size, paths := range sizeMap {
		if len(paths) < 2 {
			continue
		}

		for _, path := range paths {
			qh, err := hash.Quick(path)
			if err != nil {
				log.Printf("quick hash error: %s: %v", path, err)
				continue
			}

			key := buildQuickKey(size, qh)

			quickMap[key] = append(
				quickMap[key],
				model.FileEntry{
					Path: path,
					Size: size,
				},
			)
		}
	}

	return quickMap, nil
}

// FullHash computes full hashes concurrently.
func (s *Scanner) FullHash(
	quickMap map[string][]model.FileEntry,
) ([]model.FileEntry, error) {

	jobs := make(chan model.FileEntry, 256)
	results := make(chan model.FileEntry, 256)

	var wg sync.WaitGroup

	workers := runtime.NumCPU()

	for i := 0; i < workers; i++ {
		wg.Add(1)

		go func() {
			defer wg.Done()

			for entry := range jobs {
				h, err := hash.File(entry.Path)
				if err != nil {
					log.Printf("hash error: %s: %v", entry.Path, err)
					continue
				}

				entry.Hash = h

				results <- entry
			}
		}()
	}

	go func() {
		defer close(jobs)

		for _, entries := range quickMap {
			if len(entries) < 2 {
				continue
			}

			for _, entry := range entries {
				jobs <- entry
			}
		}
	}()

	go func() {
		wg.Wait()
		close(results)
	}()

	var out []model.FileEntry

	for r := range results {
		out = append(out, r)
	}

	return out, nil
}

// Persist writes results to the database.
func (s *Scanner) Persist(
	entries []model.FileEntry,
) error {

	if s.Store == nil {
		return nil
	}

	for _, entry := range entries {
		if err := s.Store.UpsertFile(entry); err != nil {
			log.Printf("db write: %v", err)
		}
	}

	return nil
}

// AggregateDuplicates converts entries into the
// output shape expected by output.Emit().
func AggregateDuplicates(
	entries []model.FileEntry,
) map[string][]string {

	hashMap := make(map[string][]string)

	for _, entry := range entries {
		hashMap[entry.Hash] = append(
			hashMap[entry.Hash],
			entry.Path,
		)
	}

	return hashMap
}

func buildQuickKey(size int64, hash string) string {
	return fmt.Sprintf("%d:%s", size, hash)
}

func (s *Scanner) skipDir(
	root,
	name,
	path string,
) bool {

	if path != root && strings.HasPrefix(name, ".") {
		return true
	}

	for _, ex := range s.Config.Exclude {
		if name == ex {
			return true
		}
	}

	return false
}
