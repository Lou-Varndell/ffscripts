package db

import (
	"database/sql"
	"fmt"
	"os"
	"path/filepath"

	_ "github.com/mattn/go-sqlite3"

	"fddup/internal/model"
)

type Store struct {
	DB *sql.DB
}

func Open(path string) (*Store, error) {
	if err := os.MkdirAll(filepath.Dir(path), 0755); err != nil {
		return nil, err
	}

	database, err := sql.Open(
		"sqlite3",
		path+"?_journal=WAL&_busy_timeout=5000",
	)
	if err != nil {
		return nil, err
	}

	store := &Store{
		DB: database,
	}

	if err := store.init(); err != nil {
		database.Close()
		return nil, err
	}

	return store, nil
}

func (s *Store) Close() error {
	return s.DB.Close()
}

func (s *Store) init() error {
	_, err := s.DB.Exec(`
		CREATE TABLE IF NOT EXISTS files (
			path    TEXT PRIMARY KEY,
			size    INTEGER NOT NULL,
			hash    TEXT NOT NULL,
			seen_at DATETIME DEFAULT CURRENT_TIMESTAMP
		);

		CREATE INDEX IF NOT EXISTS idx_hash
		ON files(hash);
	`)
	return err
}

func (s *Store) UpsertFile(entry model.FileEntry) error {
	_, err := s.DB.Exec(`
		INSERT INTO files (path, size, hash, seen_at)
		VALUES (?, ?, ?, CURRENT_TIMESTAMP)

		ON CONFLICT(path) DO UPDATE SET
			size    = excluded.size,
			hash    = excluded.hash,
			seen_at = CURRENT_TIMESTAMP
	`,
		entry.Path,
		entry.Size,
		entry.Hash,
	)

	if err != nil {
		return fmt.Errorf("upsert file: %w", err)
	}

	return nil
}
